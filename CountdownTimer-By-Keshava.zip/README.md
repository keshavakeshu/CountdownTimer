# CountDownTimer

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.1.1.

## Install npm Dependencies

Run `npm install` in the root folder


## Development server

Run `npm start` or `ng serve --port 4200` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically open in the browser